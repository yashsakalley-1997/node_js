let multiply = (a,b)=>{
    console.log("multiplication",a*b)
}

module.exports = multiply