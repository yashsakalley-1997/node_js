let add = (a,b) =>{
    console.log("addition",a+b);
}


module.exports = add;