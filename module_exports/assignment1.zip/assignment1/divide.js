let divide = (a,b) =>{
    console.log("division",a/b)
}


module.exports = divide;
