let subtract = (a,b)=>{
    console.log("subtraction",a-b)
}

module.exports = subtract;